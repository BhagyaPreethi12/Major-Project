from django import forms
from .models import Video,Audio
from .models import RecordedAudio
class VideoUploadForm(forms.ModelForm):
    class Meta:
        model = Video
        # fields = ['title', 'video_file']
        fields = ['video_file']
class AudioUploadForm(forms.ModelForm):
    class Meta:
        model = Audio
        fields = ['title', 'audio_file']


class RecordedAudioForm(forms.ModelForm):
    class Meta:
        model = RecordedAudio
        fields = ['audio_file']

# class AudioRecordForm(forms.Form):
#     audio = forms.FileField(
#         label='Upload Recorded Audio',
#         required=True,
#         widget=forms.ClearableFileInput(attrs={'accept': 'audio/wav'})
#     )

