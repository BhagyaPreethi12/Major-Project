import tempfile
import os
import mimetypes
import cv2
import whisper 
from collections import Counter
from django.shortcuts import render, redirect,get_object_or_404
from django.conf import settings
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .models import Video, Audio
from .forms import VideoUploadForm, AudioUploadForm
from .forms import RecordedAudioForm
from PIL import Image
import torch
import json
# from your_transcription_module import a_to_t
import speech_recognition as sr
from pydub import AudioSegment
from transformers import BlipProcessor, BlipForQuestionAnswering
from pydub import AudioSegment


def front(request):
    return render(request,'home.html')

# Load the VQA model and processor
processor = BlipProcessor.from_pretrained("Salesforce/blip-vqa-base")
model = BlipForQuestionAnswering.from_pretrained("Salesforce/blip-vqa-base")

# Initialize the recognizer
recognizer = sr.Recognizer()

# Function to extract frames from video
def extract_frames(video_path, output_dir, frame_rate=30):
    cap = cv2.VideoCapture(video_path)
    os.makedirs(output_dir, exist_ok=True)

    count = 0
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        if count % frame_rate == 0:
            frame_filename = os.path.join(output_dir, f"frame_{count}.jpg")
            cv2.imwrite(frame_filename, frame)
        count += 1

    cap.release()
def video_list(request):
    videos = Video.objects.all()  # Fetch all uploaded videos
    return render(request, 'video_list.html', {'videos': videos})
'''
def analyze_video_frames(request, video_id):
    video = get_object_or_404(Video, id=video_id)
    frames_directory = os.path.join(settings.MEDIA_ROOT, 'frames', str(video.id))  # Directory with extracted frames
    question = "what is color of the shirt?"
    
    # Get the consolidated answer
    consolidated_answer = aggregate_answers(frames_directory, question)

    return render(request, 'video_analysis.html', {
        'video': video,
        'consolidated_answer': consolidated_answer
    })
'''
'''
# Step 1: Load and convert audio to text
'''
'''
def audio_to_text(audio_file):
    with sr.AudioFile(audio_file) as source:
        audio = recognizer.record(source)
    try:
        text = recognizer.recognize_google(audio)
        print(text)
        return text
    except sr.UnknownValueError:
        return None
    except sr.RequestError as e:
        print(f"Could not request results from Google Speech Recognition service; {e}")
        return None
'''    
# 
# Step 2: Process each frame and collect answers
def get_answer_from_frame(frame_path, question):
    image = Image.open(frame_path).convert('RGB')
    inputs = processor(images=image, text=question, return_tensors="pt")
    with torch.no_grad():
        outputs = model.generate(**inputs)
    answer = processor.decode(outputs[0], skip_special_tokens=True)
    return answer

# Aggregate answers
def aggregate_answers(frames_directory, question):
    answers = []
    for frame_name in sorted(os.listdir(frames_directory)):
        frame_path = os.path.join(frames_directory, frame_name)
        answer = get_answer_from_frame(frame_path, question)
        answers.append(answer)
    most_common_answer = Counter(answers).most_common(1)[0][0]
    return most_common_answer
    # combined_answer = " ".join(answers)
    # print(combined_answer)
    # return combined_answer

def upload_video(request):
    if request.method == 'POST':
        form = VideoUploadForm(request.POST, request.FILES)
        if form.is_valid():
            video = form.save()
            # Extract frames from the uploaded video
            video_path = video.video_file.path  # Get the path to the uploaded video
            frames_directory = os.path.join('media', 'frames', str(video.id))  # Create directory for frames
            extract_frames(video_path, frames_directory, frame_rate=30)  # Extract frames
            return redirect('record_audio')  # Redirect to record audio view
    else:
        form = VideoUploadForm()
    return render(request, 'video_upload.html', {'form': form})
'''
def record_audio(request):
    if request.method == 'POST':
        print("Audio form submitted") 
        audio_file = request.FILES.get('audio')
        if audio_file:
            Audio.objects.create(audio_file=audio_file)
            # Process audio to get the question
            question = audio_to_text(audio_file)
            if question:
                # If transcription was successful, proceed with analysis
                print(f"Transcribed Question: {question}")  # DEBUG: Check the transcribed question
                frames_directory = os.path.join('media', 'frames', str(Video.objects.last().id))  # Use the last uploaded video
                consolidated_answer = aggregate_answers(frames_directory, question)
                return render(request, 'video_analysis.html',{
                    'video': Video.objects.last(),
                    'consolidated_answer': consolidated_answer,
                    'question': question  # Pass the question to display it
                })
            else:
                print("Transcription failed")
                return JsonResponse({'error': 'Failed to transcribe audio'}, status=400)
        else:
            print("No audio file provided")  # DEBUG: Audio upload issue
            return JsonResponse({'error': 'No audio file uploaded'}, status=400)

    return render(request, 'record_audio.html')
'''

'''
def record_audio(request):
    if request.method == 'POST':
        audio_file = request.FILES.get('audio')  # Get the uploaded audio file
        if audio_file:
            Audio.objects.create(audio_file=audio_file)  # Save the audio file to the database

            # Convert the audio to text (use speech recognition)
            question = audio_to_text(audio_file)
            print(question)

            if question:
                # If transcription was successful, proceed with video frame analysis
                frames_directory = os.path.join('media', 'frames', str(Video.objects.last().id))  # Get the directory of the last uploaded video's frames
                consolidated_answer = aggregate_answers(frames_directory, question)

                # Render the result in the video_analysis.html
                return render(request, 'video_analysis.html', {
                    'video': Video.objects.last(),
                    'consolidated_answer': consolidated_answer,
                    'question': question  # Display the transcribed question
                })
            else:
                return JsonResponse({'error': 'Failed to transcribe audio'}, status=400)
    return render(request, 'record_audio.html')
'''

'''
recognizer = sr.Recognizer()

def audio_to_text(audio_file):
    # Step 1: Convert the uploaded audio to WAV format
    try:
        audio_format = audio_file.name.split('.')[-1]  # Get the file extension (e.g., 'mp3')
        audio_path = audio_file.temporary_file_path()  # Get the temporary file path
        if audio_format != 'wav':
            # Convert non-wav audio to wav using pydub
            audio = AudioSegment.from_file(audio_path, format=audio_format)
            wav_path = os.path.splitext(audio_path)[0] + '.wav'  # Create wav file path
            audio.export(wav_path, format='wav')  # Export audio as wav
            audio_file = wav_path  # Update to the new wav file path

        # Step 2: Process the WAV audio file using speech recognition
        with sr.AudioFile(audio_file) as source:
            audio_data = recognizer.record(source)  # Record the audio data

        # Step 3: Transcribe the audio using Google API
        text = recognizer.recognize_google(audio_data)
        print(f"Transcribed Text: {text}")
        return text

    except sr.UnknownValueError:
        print("Google Speech Recognition could not understand audio")
        return None
    except sr.RequestError as e:
        print(f"Could not request results from Google Speech Recognition service; {e}")
        return None
    except Exception as e:
        print(f"Error processing audio: {e}")
        return None
'''

 







''''
def record_audio(request):
    if request.method == 'POST':
        audio_file = request.FILES.get('audio')  # Get the uploaded audio file
        if audio_file:
            Audio.objects.create(audio_file=audio_file)  # Save the audio file to the database
            print(f"Audio file uploaded: {audio_file.name}")

            # Convert the audio to text (use speech recognition)
            question = audio_to_text(audio_file)
            print(f"Transcribed question: {question}")

            if question:
                # If transcription was successful, proceed with video frame analysis
                frames_directory = os.path.join('media', 'frames', str(Video.objects.last().id))  # Get the directory of the last uploaded video's frames
                consolidated_answer = aggregate_answers(frames_directory, question)

                # Render the result in the video_analysis.html
                return render(request, 'video_analysis.html', {
                    'video': Video.objects.last(),
                    'consolidated_answer': consolidated_answer,
                    'question': question  # Display the transcribed question
                })
            else:
                print("Failed to transcribe audio.")
                return JsonResponse({'error': 'Failed to transcribe audio'}, status=400)

    return render(request, 'record_audio.html')


def audio_to_text(audio_file):
    try:
        # Check if the file is an InMemoryUploadedFile or TemporaryUploadedFile
        if hasattr(audio_file, 'temporary_file_path'):
            audio_path = audio_file.temporary_file_path()  # If stored on disk
        else:
            # If the file is in memory, save it to a temporary location
            audio_path = f'/tmp/{audio_file.name}'
            with open(audio_path, 'wb+') as f:
                for chunk in audio_file.chunks():
                    f.write(chunk)

        # Convert to WAV format using pydub if not already WAV
        file_format = audio_file.name.split('.')[-1].lower()
        if file_format != 'wav':
            audio = AudioSegment.from_file(audio_path, format=file_format)
            wav_path = os.path.splitext(audio_path)[0] + '.wav'
            audio.export(wav_path, format='wav')
            audio_path = wav_path

        # Use speech_recognition to transcribe the WAV audio
        with sr.AudioFile(audio_path) as source:
            audio_data = recognizer.record(source)

        # Recognize the speech using Google API
        text = recognizer.recognize_google(audio_data)
        print(f"Transcribed Text: {text}")
        return text

    except sr.UnknownValueError:
        print("Google Speech Recognition could not understand audio")
        return None
    except sr.RequestError as e:
        print(f"Could not request results from Google Speech Recognition service; {e}")
        return None
    except Exception as e:
        print(f"Error processing audio: {e}")
        return None
'''
recognizer = sr.Recognizer()

# def audio_to_text(audio_file_path):
#     try:
#         # Use speech_recognition to transcribe the WAV audio
#         with sr.AudioFile(audio_file_path) as source:
#             audio_data = recognizer.record(source)

#         # Recognize the speech using Google API
#         text = recognizer.recognize_google(audio_data)
#         print(f"Transcribed Text: {text}")
#         return text

#     except sr.UnknownValueError:
#         print("Google Speech Recognition could not understand audio")
#         return None
#     except sr.RequestError as e:
#         print(f"Could not request results from Google Speech Recognition service; {e}")
#         return None
#     except Exception as e:
#         print(f"Error processing audio: {e}")
#         return None

def convert_to_wav(input_path):
    output_path = os.path.splitext(input_path)[0]  
    # "_converted.wav"
    print(output_path)
    try:
        audio = AudioSegment.from_file(input_path)
        audio = audio.set_channels(1)  # Convert to mono
        audio = audio.set_frame_rate(16000)  # Set sample rate to 16kHz
        audio.export(output_path, format="wav", parameters=["-ac", "1", "-ar", "16000"])
        # print(output_path)
        return output_path
    except Exception as e:
        print(f"Error converting audio: {e}")
        return None
def audio_to_text(audio_file_path):
    try:
        print("hi")
        recognizer = sr.Recognizer()
        

        # Ensure the file is properly formatted
        # audio_file_path = convert_to_wav(audio_file_path) or audio_file_path
        print(audio_file_path)
        with sr.AudioFile(audio_file_path) as source:
            audio_data = recognizer.record(source)
            print(audio_data)

        text = recognizer.recognize_google(audio_data)
        print(f"Transcribed Text: {text}")
        if text==None:
            text=convert_to_wav(audio_file_path)
        return text

    except sr.UnknownValueError:
        print("Error: Could not understand the audio")
    except sr.RequestError as e:
        print(f"Error: Google API request failed: {e}")
    except Exception as e:
        print(f"Unexpected error: {e}")

    return None

# def record_audio(request):
#     if request.method == 'POST':
#         audio_file = request.FILES.get('audio')  # Get the uploaded audio file
#         if audio_file:
#             # Save the uploaded audio file to a temporary location
#             with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as temp_audio:
#                 for chunk in audio_file.chunks():
#                     temp_audio.write(chunk)
#                 temp_audio_path = temp_audio.name  # Get the temporary file's path

#             print(f"Audio file saved to: {temp_audio_path}")

#             # Optionally, check and convert to WAV format using pydub if needed
#             audio_format = audio_file.name.split('.')[-1].lower()
#             if audio_format != 'wav':
#                 audio = AudioSegment.from_file(temp_audio_path, format=audio_format)
#                 temp_wav_path = os.path.splitext(temp_audio_path)[0] + '.wav'
#                 audio.export(temp_wav_path, format='wav')
#                 temp_audio_path = temp_wav_path  # Update the path to the converted file
#                 # Convert the saved audio to text
#             question = audio_to_text(temp_audio_path)
#             print(f"Transcribed question: {question}")

#             if question:
#                 # If transcription was successful, proceed with video frame analysis
#                 frames_directory = os.path.join('media', 'frames', str(Video.objects.last().id))  # Get the directory of the last uploaded video's frames
#                 consolidated_answer = aggregate_answers(frames_directory, question)

#                 # Render the result in the video_analysis.html
#                 return render(request, 'video_analysis.html', {
#                     'video': Video.objects.last(),
#                     'consolidated_answer': consolidated_answer,
#                     'question': question  # Display the transcribed question
#                 })
#             else:
#                 print(temp_audio_path)
#                 print(audio_format)

#                 return JsonResponse({'error': 'Failed to transcribe audio'}, status=400)

#     return render(request, 'record_audio.html')

import os
from django.core.files.storage import default_storage
from django.core.files.base import ContentFile
from django.http import JsonResponse
from django.shortcuts import render
from pydub import AudioSegment
import speech_recognition as sr

# Ensure media folder exists
MEDIA_AUDIO_PATH = os.path.join(settings.MEDIA_ROOT,'audio')
os.makedirs(MEDIA_AUDIO_PATH, exist_ok=True)

def record_audio(request):
    if request.method == 'POST':
        audio_file = request.FILES.get('audio')  # Get the uploaded audio file
        if audio_file:
            # Define the save path inside media/audio/
            audio_filename = audio_file.name
            save_path = os.path.join(MEDIA_AUDIO_PATH, audio_filename)

            # Save the uploaded file to the media folder
            with default_storage.open(save_path, 'wb+') as destination:
                for chunk in audio_file.chunks():
                    destination.write(chunk)

            print(f"Audio file saved to: {save_path}")

            # Ensure the file is in WAV format
            audio_format = audio_filename.split('.')[-1].lower()
            if audio_format != 'wav':
                audio = AudioSegment.from_file(save_path, format=audio_format)
                converted_path = os.path.splitext(save_path)[0] + '.wav'
                audio.export(converted_path, format='wav')
                save_path = converted_path  # Update to the converted WAV file

            # Convert the saved audio to text
            question = audio_to_text(save_path)
            print(f"Transcribed question: {question}")

            if question:
                # If transcription was successful, proceed with video frame analysis
                frames_directory = os.path.join('media', 'frames', str(Video.objects.last().id))  # Get the directory of the last uploaded video's frames
                consolidated_answer = aggregate_answers(frames_directory, question)
                

                # Render the result in video_analysis.html
                return render(request, 'video_analysis.html', {
                    'video': Video.objects.last(),
                    'consolidated_answer': consolidated_answer,
                    'question': question # Display the transcribed question
                    # 'comm':combined_answer
                })
            else:
                return JsonResponse({'error': 'Failed to transcribe audio'}, status=400)

    return render(request, 'record_audio.html')

def validate_audio_format(audio_file):
    valid_formats = ['wav', 'mp3', 'flac', 'ogg', 'm4a', 'aac']
    file_format = audio_file.name.split('.')[-1].lower()
    print(f"Uploaded audio format: {file_format}")
    return file_format in valid_formats

def analyze_video_and_audio(request):
    # This view may be unnecessary since we analyze in the record_audio view
    pass
def ans(request):
    return render(request,'video_analysis.html')

import os
import tempfile
from django.http import JsonResponse
from django.shortcuts import render
from pydub import AudioSegment
import speech_recognition as sr
import wave
import mimetypes
from .models import Video

def dir_record_audio(request):
    if request.method == 'POST':
        audio_file = request.FILES.get('audio')

        if not audio_file:
            return JsonResponse({'error': 'No audio file received'}, status=400)

        # ✅ Print MIME Type
        import mimetypes
        mime_type, _ = mimetypes.guess_type(audio_file.name)
        print(f"📂 Uploaded file name: {audio_file.name}")
        print(f"📋 Detected MIME type: {mime_type}")

        # ✅ Save the uploaded file temporarily
        with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as temp_audio:
            for chunk in audio_file.chunks():
                temp_audio.write(chunk)
            temp_audio_path = temp_audio.name

        print(f"📂 Saved temporary audio at: {temp_audio_path}")

        # ✅ Forcefully convert to proper PCM WAV
        fixed_audio_path = force_convert_to_wav(temp_audio_path)
        if fixed_audio_path is None:
            return JsonResponse({'error': 'Audio conversion failed'}, status=500)

        # ✅ Validate the newly converted file
        if not is_valid_pcm_wav(fixed_audio_path):
            print("🚨 Error: File is still not PCM WAV format")
            return JsonResponse({'error': 'Invalid PCM WAV file'}, status=400)

        # ✅ Convert to text
        question = a_to_t(fixed_audio_path)
        print(f"📝 Transcribed text: {question}")

        if question:
            frames_directory = os.path.join('media', 'frames', str(Video.objects.last().id))
            consolidated_answer = aggregate_answers(frames_directory, question)
            print(consolidated_answer)

            return render(request, 'video_analysis.html', {
                'video': Video.objects.last(),
                'consolidated_answer': consolidated_answer,
                'question': question
            })
        else:
            return JsonResponse({'error': 'Failed to transcribe audio'}, status=400)

    return render(request, 'dir_rec.html')



def a_to_t(audio_path):
    """
    Converts audio to text using OpenAI Whisper or SpeechRecognition.
    """
    try:
        model = whisper.load_model("base")  # Whisper model
        result = model.transcribe(audio_path,language="en")
        return result["text"]
    except Exception as e:
        print(f"Whisper error: {e}")
        # Fallback to SpeechRecognition
        recognizer = sr.Recognizer()
        with sr.AudioFile(audio_path) as source:
            audio_data = recognizer.record(source)
            try:
                return recognizer.recognize_google(audio_data)  # Google Speech-to-Text
            except sr.UnknownValueError:
                return None
            except sr.RequestError as e:
                print(f"SpeechRecognition error: {e}")
                return None
def c_to_wav(input_path):
    """
    Converts any audio file to a properly formatted WAV file (PCM 16-bit, Mono, 16kHz).
    """
    output_path = os.path.splitext(input_path)[0] + '_converted.wav'
    audio = AudioSegment.from_file(input_path)
    
    # Ensure correct format: Mono, 16kHz, 16-bit PCM
    audio = audio.set_channels(1).set_frame_rate(16000).set_sample_width(2)
    audio.export(output_path, format='wav', codec='pcm_s16le')

    print(f"Converted audio saved to: {output_path}")  # Debugging
    return output_path



def is_valid_pcm_wav(file_path):
    """
    Checks if the WAV file is a valid PCM encoded file.
    """
    try:
        with wave.open(file_path, 'rb') as wf:
            print(f"Audio parameters: {wf.getparams()}")  # Debug info
            return wf.getsampwidth() == 2  # Ensures 16-bit PCM
    except wave.Error as e:
        print(f"Wave file error: {e}")
        return False

# Add this check before sending to whisper/speech_recognition
# if not is_valid_pcm_wav(temp_audio_path):
#     print("Error: File is not PCM WAV format")
#     return JsonResponse({'error': 'Invalid PCM WAV file'}, status=400)


def force_convert_to_wav(input_path):
    """
    Forces conversion of any audio file (even invalid WAV) to a proper PCM WAV (16-bit, Mono, 16kHz).
    """
    output_path = os.path.splitext(input_path)[0] + '_fixed.wav'
    try:
        # Load the file (even if it's incorrectly named as .wav)
        audio = AudioSegment.from_file(input_path)

        # Convert to PCM WAV (16-bit, 16kHz, Mono)
        audio = audio.set_channels(1).set_frame_rate(16000).set_sample_width(2)
        audio.export(output_path, format='wav', codec='pcm_s16le')

        print(f"✅ Forced conversion: Saved proper PCM WAV at {output_path}")
        return output_path
    except Exception as e:
        print(f"🚨 Error in force-converting audio: {e}")
        return None
    



# Manually set the FFmpeg path
AudioSegment.converter =r"C:\ProgramData\chocolatey\lib\ffmpeg\ffmpeg-7.0.2-essentials_build\bin\ffmpeg.exe" # Path to ffmpeg executable
AudioSegment.ffprobe = r"C:\ProgramData\chocolatey\lib\ffmpeg\ffmpeg-7.0.2-essentials_build\bin\ffprobe.exe" # Path to ffprobe executable

def force_convert_to_wav(input_path):
    """
    Forces conversion of any audio file (even invalid WAV) to a proper PCM WAV (16-bit, Mono, 16kHz).
    """
    output_path = os.path.splitext(input_path)[0] + '_fixed.wav'
    try:
        # Load the file (even if it's incorrectly named as .wav)
        audio = AudioSegment.from_file(input_path)

        # Convert to PCM WAV (16-bit, 16kHz, Mono)
        audio = audio.set_channels(1).set_frame_rate(16000).set_sample_width(2)
        audio.export(output_path, format='wav', codec='pcm_s16le')

        print(f"✅ Forced conversion: Saved proper PCM WAV at {output_path}")
        return output_path
    except Exception as e:
        print(f"🚨 Error in force-converting audio: {e}")
        return None
    
def transcribe(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        fixed_audio_path = data.get('audio_path')
        question = a_to_t(fixed_audio_path)
        return JsonResponse({'transcription': question})
    

