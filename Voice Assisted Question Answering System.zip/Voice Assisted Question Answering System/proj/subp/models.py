from django.db import models

class Video(models.Model):
    video_file = models.FileField(upload_to='videos/')

    def __str__(self):
        return str(self.video_file)

    
from django.db import models

class Audio(models.Model):
    title = models.CharField(max_length=100)  # Field to store the title of the audio
    audio_file = models.FileField(upload_to='audio/')  # Field to store the uploaded audio file

    def __str__(self):
        return self.title
    
class RecordedAudio(models.Model):
    audio_file = models.FileField(upload_to='recordings/', verbose_name='Recorded Audio')
    uploaded_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"Recording uploaded on {self.uploaded_at}"

    