
from django.urls import path
from . import views
'''
urlpatterns = [
    path('first/', views.fir, name='a'),
    path('upload/',views.video_upload,name="video_upload"),
    path('videos/', views.video_list, name='video_list'),  
    path('extract_frames/<int:video_id>/', views.extract_frames_from_video, name='extract_frames'),
    path('analyze/<int:video_id>/', views.analyze_video_frames, name='analyze_video_frames'),  # New URL
    path('record-audio/',views.record_audio,name='record_audio'),  # New URL for recording audio
]
'''

urlpatterns = [
    path('',views.front),
    # path('analyze/<int:video_id>/', views.analyze_video_frames, name='analyze_video_frames'),
    path('upload-video/',views.upload_video,name='upload_video'),  # URL for uploading video
    path('record-audio/', views.record_audio, 
    name='record_audio'),  # URL for recording audio
    # If you want to keep the analyze view, you can uncomment the next line
    path('videos/', views.video_list, name='video_list'), 
    # path('analyze/', views.analyze_video_and_audio, name='analyze_video_and_audio'),
    # path('extract_frames/<int:video_id>/', views.extract_frames_from_video, name='extract_frames'),
    path('video_analysis',views.ans),
    path('dir_record/', views.dir_record_audio, name='record_audio'),
]