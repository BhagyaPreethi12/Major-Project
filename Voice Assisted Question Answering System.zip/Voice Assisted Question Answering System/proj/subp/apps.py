from django.apps import AppConfig


class SubpConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'subp'
